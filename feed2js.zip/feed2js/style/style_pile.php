<?php
// css file name  => title
$mystyles = array(
	'basic1'=> 'Basic Blue',
	'bbc_style' => 'BBC',
	'blackbox' => 'Blackbox',
	'dog' => 'Dog\'s Eye View',
	'essc' => 'ESSC',
	'greenbars' => 'Green Bars',
	'kp' => 'KP',
	'marooned2' => 'Marooned',
	'none' => 'No Style / Blank Template',
	'nobullets' => 'No Bullets',
	'outlive' => 'OutlivE',
	'plum' => 'Plum',
	'princessthing' => 'Princess',
	'sekodeng' => 'Sekodeng',
	'zanestate' => 'Zanestate Yahoo',
	);
?> 
